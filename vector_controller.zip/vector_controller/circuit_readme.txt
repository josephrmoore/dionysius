These are the files and instructions you'll need to make the box and controller for the Dionysius vector instrument. In this document you have an explanation about the circuit and complete inventory of parts used. 

There is also a PDF of 3 different possible templates for having the outer box laser cut from wood. Each layer is for a different thickness. Use the patters with fewer teeth for thicker wood (i.e. 1/2 wood, use the one with the biggest teeth, 1/4 middle, and 1/8 inch the smallest teeth) The wood I used was 1/8 of an inch so I used the smallest teeth. This file is not perfect, it's just what I used. The knob holes were a little too snug. Ideally you should add a circle hole in the middle where the roller sits so you could mount it from underneath inside the box. I did not account for a power cord hole nor for the two extra knobs I added in the second iteration, or the key hole. I manually added them with a drill after the fact. I used really light wood for the box, so I cut a duplicate of the top face (where the holes are and the components connect) in a heavier wood, and glued it as a reinforcement under the top panel. This made it a little too deep for the potentiometers, so if you do it, cut bigger holes in the support wood for the potentiometer housing or buy one with longer knobs.

Lastly, the arduino code I used to control the code is in a folder called /arduino_sketch. I used an Arduino Mega and is writing accordingly.

CIRCUIT INFORMATION

The controller uses these parts:

(2) claw game joystick with button
(1) roller ball
(1) arcade button
(1) big cartoony button
(5) potentiometers
(1) key lock switch
(1) breadboard
resistors

The rollerball uses a PS/2 cord and required a PS/2 to wires adapter. I used this tutorial to get the rollerball sending input to my code:

http://playground.arduino.cc/componentLib/Ps2mouse

The potentiometers require analog inputs. You must have sufficient voltage going through them to get a reliable signal. I used one 3V and another 5V from the Mega going into the circuit to overcome the natural resistance enough to get a workable and steady signal.  

The joysticks buttons and key switch just required a pull-down resistor to get reliable signals. Each one was inserted into a digital input on the Mega.

The arduino code takes the signals, and converts them to an array of space separated values that are sent over serial to openFrameworks. The software interprets these values as the values they represent.

I used the breadboard to pool voltage and grounds, attaching multiple switches to the same rows. 

LINKS TO PARTS

https://www.sparkfun.com/products/10758 Trackball
https://www.sparkfun.com/products/9136 Joystick
https://www.sparkfun.com/products/9336 Arcade button
https://www.sparkfun.com/products/9181 Big button
https://www.sparkfun.com/products/9939 Potentiometer
https://www.sparkfun.com/products/10002 Potentiometer knob
